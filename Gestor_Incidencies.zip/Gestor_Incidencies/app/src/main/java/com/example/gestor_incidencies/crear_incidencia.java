package com.example.gestor_incidencies;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class crear_incidencia extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.crear_incidencia_lyt);
    }
}