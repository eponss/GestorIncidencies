package com.example.gestor_incidencies;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class gestionar_incidencia extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gestionar_incidencia_lyt);
    }
}